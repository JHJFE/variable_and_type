function computeAverageLengthOfWords2(word1, word2) {
  // TODO: 여기에 코드를 작성합니다.
  let len1 = word1.length;
  let len2 = word2.length;

  let avglen = Math.floor((len1 + len2) / 2);
  return console.log(avglen);
}
computeAverageLengthOfWords2('chicken', 'beer');
